﻿namespace StackManagement.Model
{
    public class SaleView
    {
        public int id { get; set; }
        public int itemId { get; set; }
        public string itemName { get; set; }

        public string takenQuentity { get; set; }
    }
}