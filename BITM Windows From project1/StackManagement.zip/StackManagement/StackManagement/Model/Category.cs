﻿using System;

namespace StackManagement.Model
{
    internal class Category
    {
        public int id { get; set; }
        public string catName { get; set; }
        public DateTime date { get; set; }
        public DateTime updateDate { get; set; }
    }
}