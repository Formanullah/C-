﻿namespace StackManagement.Model
{
    internal class Serch_View
    {
        public int id { get; set; }
        public int catId { get; set; }
        public int compId { get; set; }
        public string itemName { get; set; }
        public string companyName { get; set; }
        public string catName { get; set; }
        public int aviableQuantity { get; set; }
        public int reorderLabel { get; set; }
    }
}