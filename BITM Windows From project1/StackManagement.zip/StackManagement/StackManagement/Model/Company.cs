﻿using System;

namespace StackManagement.Model
{
    internal class Company
    {
        public int id { get; set; }
        public string name { get; set; }
        public DateTime date { get; set; }
    }
}